package br.unipac.computacaomovel;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;

public class SegundaTelaActivity extends AppCompatActivity {
    SeekBar skHomens;
    SeekBar skMulheres;
    SeekBar skCriancas;
    TextView rHomens;
    TextView rMulheres;
    TextView rCriancas;
    Button btnNext;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_tela);
        skHomens = findViewById(R.id.skHomens);
        skMulheres = findViewById(R.id.skMulheres);
        skCriancas= findViewById(R.id.skCriancas);

        rHomens = findViewById(R.id.rHomens);
        rMulheres = findViewById(R.id.rMulheres);
        rCriancas = findViewById(R.id.rCriancas);
        btnNext = findViewById(R.id.btnNext);


        skHomens.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                rHomens.setText(""+skHomens.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        skMulheres.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                rMulheres.setText(""+skMulheres.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        skCriancas.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                rCriancas.setText(""+skCriancas.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SegundaTelaActivity.this,TerceiraTelaActivity.class);
                startActivity(intent);
            }
        });

    }


}
