package br.unipac.computacaomovel;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class TerceiraTelaActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_tela);
    }
}
