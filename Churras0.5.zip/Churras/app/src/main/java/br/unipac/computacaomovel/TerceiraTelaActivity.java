﻿package br.unipac.computacaomovel;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

public class TerceiraTelaActivity extends AppCompatActivity {

    private TextView txtResultPorco;
    private TextView txtResultFrango;
    private TextView txtResultBoi;
    private TextView txtResultLinguica;
    private TextView txtResultCerveja;
    private TextView txtResultRefri;
    private Double pPorco = 0.0;
    private Double pBoi = 0.0;
    private Double pFrango = 0.0;
    private Double pLinguica = 0.0;
    private Double qtdPessoas = 0.0;
    private Double calcPeso = 0.0;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terceira_tela);

        txtResultBoi = findViewById(R.id.txtResultBoi);
        txtResultPorco = findViewById(R.id.txtResultPorco);
        txtResultFrango = findViewById(R.id.txtResultFrango);
        txtResultLinguica = findViewById(R.id.txtResultLinguica);


        txtResultRefri = findViewById(R.id.txtResultRefri);
        txtResultCerveja = findViewById(R.id.txtResultCerveja);

        Bundle dados = getIntent().getExtras();

        Double qtdHomens = Double.valueOf(dados.getString("Homens"));
        Double qtdMulheres = Double.valueOf(dados.getString("Mulheres"));
        Double qtdCriancas = Double.valueOf(dados.getString("Criancas"));



        Boolean boi = Boolean.valueOf(dados.getString("boi"));
        Boolean porco = Boolean.valueOf(dados.getString("porco"));
        Boolean frango = Boolean.valueOf(dados.getString("frango"));
        Boolean linguica = Boolean.valueOf(dados.getString("linguica"));

        Double cerveja = Double.valueOf(dados.getString("cerveja"));
        Double refri = Double.valueOf(dados.getString("refri"));

        qtdHomens *= 400;
        qtdMulheres *=300;
        qtdCriancas *= 150;
        qtdPessoas = qtdCriancas+qtdHomens+qtdMulheres;
	
	verificaPorcentagem(boi,porco,linguica,frango);

        txtResultPorco.setText("Porco:"+(qtdPessoas*pPorco)+" gramas");
        txtResultBoi.setText("Boi:"+(qtdPessoas*pBoi)+" gramas");
        txtResultFrango.setText("Frango:"+(qtdPessoas*pFrango)+" gramas");
        txtResultLinguica.setText("Linguiça:"+(qtdPessoas*pLinguica)+" gramas");


        cerveja *= 3;
        refri *=500;
        txtResultCerveja.setText("Latas de breja:"+cerveja);
        txtResultRefri.setText("Qauntidade de refri:"+refri+"ml");

           
    }


    void verificaPorcentagem(Boolean boi,Boolean porco,Boolean linguica,Boolean frango){ 
        if(boi==true){
            this.calcPeso+=0.4;
	    this.pBoi=0.4;
          }
	 
	if(porco==true){
            this.calcPeso+=0.2;
	    this.pPorco=0.2;
        }
	
	if(linguica==true){
            this.calcPeso+=0.25;
	    this.pLinguica=0.25;
        }
	
	if(frango==true){
            this.calcPeso+=0.15;
	    this.pFrango=0.15;
        }
      	

	if(boi==false && porco==false && linguica==false && frango==false){
            Toast t = Toast.makeText(getApplicationContext(),"Selecione ao menos 1 tipo de carne",Toast.LENGTH_LONG);
            t.show();
        }

	this.pBoi = this.pBoi/this.calcPeso
	this.pFrango = this.pFrango/this.calcPeso;
	this.plinguica = this.plinguica/this.calcPeso;
	this.pPorco = this.pPorco/this.calcPeso;
    }

}
