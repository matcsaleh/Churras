package br.unipac.computacaomovel;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import static android.view.View.VISIBLE;

public class SegundaTelaActivity extends AppCompatActivity {
    private SeekBar skHomens;
    private SeekBar skMulheres;
    private SeekBar skCriancas;
    private TextView rHomens;
    private TextView rMulheres;
    private TextView rCriancas;
    private Button btnNext;
    private EditText cerveja ;
    private EditText refri ;
    private CheckBox boi;
    private CheckBox porco;
    private CheckBox frango;
    private CheckBox linguica;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_tela);

        skHomens = findViewById(R.id.skHomens);
        skMulheres = findViewById(R.id.skMulheres);
        skCriancas= findViewById(R.id.skCriancas);

        rHomens = findViewById(R.id.rHomens);
        rMulheres = findViewById(R.id.rMulheres);
        rCriancas = findViewById(R.id.rCriancas);
        btnNext = findViewById(R.id.btnNext);




        skHomens.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                rHomens.setText(""+skHomens.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {


            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        skMulheres.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                rMulheres.setText(""+skMulheres.getProgress());
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {


            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        skCriancas.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                rCriancas.setText(""+skCriancas.getProgress());

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });


        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SegundaTelaActivity.this,TerceiraTelaActivity.class);

                cerveja = findViewById(R.id.edCerveja);
                refri = findViewById(R.id.edRefri);

                         boi = findViewById(R.id.checkBoi);
                         frango = findViewById(R.id.checkFrango);
                         linguica = findViewById(R.id.checkLinguica);
                         porco = findViewById(R.id.checkPorco);
///////////////////////////////////////////////////////////////////////////////////////
                if(verificaPessoas()) {
                    if(verificaBebidas()){
                        if(verificaCarnes()) {

                            intent.putExtra("Homens", rHomens.getText().toString());   // Passando os valores da tela 2 para tela 3 via intent.
                            intent.putExtra("Mulheres", rMulheres.getText().toString());
                            intent.putExtra("Criancas", rCriancas.getText().toString());

                            intent.putExtra("boi", "" + boi.isChecked());
                            intent.putExtra("frango", "" + frango.isChecked());
                            intent.putExtra("linguica", "" + linguica.isChecked());
                            intent.putExtra("porco", "" + porco.isChecked());


                            intent.putExtra("cerveja", cerveja.getText().toString());
                            intent.putExtra("refri", refri.getText().toString());
                            //////////////////////////////////////////////////////////////////////////////////
                            startActivity(intent);
                        }
                    }
                }
            }
        });

    }

    boolean verificaPessoas(){
        if((rCriancas.getText().toString().equals("0")) && (rHomens.getText().toString().equals("0")) && (rMulheres.getText().toString().equals("0"))){
          Toast t = Toast.makeText(getApplicationContext(),"Churrasco sem pessoas :(",Toast.LENGTH_LONG);
          t.show();
          return false;

        }

        return true;
    }

    boolean verificaBebidas(){
        Double c = Double.valueOf(cerveja.getText().toString());
        Double r = Double.valueOf(refri.getText().toString());

        Double homens = Double.valueOf(rHomens.getText().toString());
        Double mulheres = Double.valueOf(rMulheres.getText().toString());
        Double criancas = Double.valueOf(rCriancas.getText().toString());
        Double aux = homens+mulheres+criancas;


            if(cerveja.length()==0){
                cerveja.setText("0");

            }
            if(refri.length()==0){
                refri.setText("0");
            }
            if((c+r)<=aux){
                return  true;
            }
            else{
                Toast t = Toast.makeText(getApplicationContext(),"Opa mais pessoas vao beber do as pessoas que vão no churrasco",Toast.LENGTH_LONG);
                t.show();

            }
    return false;

    }
    boolean verificaCarnes(){
        if((boi.isChecked()==false)&&(porco.isChecked()==false) && (linguica.isChecked()==false) && (frango.isChecked()==false)){
            Toast t = Toast.makeText(getApplicationContext(),"Churrasco sem carne ???????????",Toast.LENGTH_LONG);
            t.show();
            return false;
        }
        return true;
    }


}
