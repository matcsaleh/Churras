package br.unipac.computacaomovel;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class TerceiraTelaActivity extends AppCompatActivity {

    private TextView txtResultPorco;
    private TextView txtResultFrango;
    private TextView txtResultBoi;
    private TextView txtResultLinguica;
    private TextView txtResultCerveja;
    private TextView txtResultRefri;
    private TextView txtCarvao;
    private TextView txtSal;
    private TextView txtCopo;
    private double pPorco = 0.0;
    private double pBoi = 0.0;
    private double pFrango = 0.0;
    private double pLinguica = 0.0;
    private double qtdPessoas = 0.0;
    private double calcPeso;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terceira_tela);

        txtResultBoi = findViewById(R.id.txtResultBoi);
        txtResultPorco = findViewById(R.id.txtResultPorco);
        txtResultFrango = findViewById(R.id.txtResultFrango);
        txtResultLinguica = findViewById(R.id.txtResultLinguica);

        TextView txtCarvao = findViewById(R.id.txtCarvao);
        TextView txtSal = findViewById(R.id.txtSal);
        TextView txtCopo = findViewById(R.id.txtCopo);


        txtResultRefri = findViewById(R.id.txtResultRefri);
        txtResultCerveja = findViewById(R.id.txtResultCerveja);

        Bundle dados = getIntent().getExtras();

        Double qtdHomens = Double.valueOf(dados.getString("Homens"));
        Double qtdMulheres = Double.valueOf(dados.getString("Mulheres"));
        Double qtdCriancas = Double.valueOf(dados.getString("Criancas"));
        int copo = (int) (qtdHomens*2 + qtdMulheres + qtdCriancas*3) ;

        Boolean boi = Boolean.valueOf(dados.getString("boi"));
        Boolean porco = Boolean.valueOf(dados.getString("porco"));
        Boolean frango = Boolean.valueOf(dados.getString("frango"));
        Boolean linguica = Boolean.valueOf(dados.getString("linguica"));

        Double cerveja = Double.valueOf(dados.getString("cerveja"));
        Double refri = Double.valueOf(dados.getString("refri"));

        verificaPorcentagem(boi, porco, linguica, frango);
        qtdHomens *= 400;
        qtdMulheres *= 300;
        qtdCriancas *= 150;
        qtdPessoas = qtdCriancas + qtdHomens + qtdMulheres;

        txtResultPorco.setText("Porco: " + (qtdPessoas * pPorco / 1000) + "KG");
        txtResultBoi.setText("Boi: " + (qtdPessoas * pBoi / 1000) + "KG");
        txtResultFrango.setText("Frango: " + (qtdPessoas * pFrango / 1000) + "KG");
        txtResultLinguica.setText("Linguiça: " + (qtdPessoas * pLinguica / 1000) + "KG");

        txtCarvao.setText("Carvão: " + (qtdPessoas * 1.5 /1000) + "KG");
        txtSal.setText("Sal: " + (qtdPessoas * 0.5 / 1000) + "KG");
        txtCopo.setText("Copo Dercartável:"+(copo/100)+" pacotes C/100u ");


        cerveja *= 3;
        refri *= 500;
        txtResultCerveja.setText("Latas de breja:" + cerveja);
        txtResultRefri.setText("Qauntidade de refri:" + refri + "ml");


    }

    /*boolean verificaPorcentagem(Boolean boi,Boolean porco,Boolean linguica,Boolean frango){

        if((boi==true) && (porco==true) && (linguica==true) && (frango==true)){
            this.pBoi=0.4;
            this.pPorco=0.2;
            this.pFrango=0.15;
            this.pLinguica=0.25;
            return true;

        }
        if((boi==true) && (porco==true) && (linguica==true) && (frango==false)){
            this.pBoi=0.5;
            this.pPorco=0.25;
            this.pLinguica=0.25;
            return true;

        }
        if((boi.equals(false))&& (porco==true) && (linguica==true) && (frango==true)){

            this.pPorco=0.5;
            this.pFrango=0.25;
            this.pLinguica=0.25;
            return true;

        }
        if((boi==true) && (porco==false) && (linguica==true) && (frango==true)){
            this.pBoi=0.5;
            this.pFrango=0.25;
            this.pLinguica=0.25;
            return true;

        }
        if((boi==true) && (porco==true) && (linguica==false) && (frango==true)){
            this.pBoi=0.4;
            this.pPorco=0.25;
            this.pFrango=0.25;
            return true;

        }
        else{
            Toast t = Toast.makeText(getApplicationContext(),"Selecione ao menos 3 tipos de carne",Toast.LENGTH_LONG);
            t.show();
        }
        return true;

    }*/

    void btnVolta(View view) {
        Intent x = new Intent(TerceiraTelaActivity.this, SegundaTelaActivity.class);
        startActivity(x);
    }

    void verificaPorcentagem(Boolean boi, Boolean porco, Boolean linguica, Boolean frango) {
        if (boi == true) {
            this.calcPeso += 0.44;
            this.pBoi = 0.44;
        }

        if (porco == true) {
            this.calcPeso += 0.22;
            this.pPorco = 0.22;
        }

        if (linguica == true) {
            this.calcPeso += 0.17;
            this.pLinguica = 0.17;
        }

        if (frango) {
            this.calcPeso += 0.17;
            this.pFrango = 0.17;
        }

        this.pBoi /= calcPeso;
        this.pFrango /= calcPeso;
        this.pLinguica  /= calcPeso;
        this.pPorco /= calcPeso;


    }
}
